﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEnemyOut : MonoBehaviour
{

    public int numObjects = 5;
    public GameObject prefab;


    void Start()
    {
       
    }


    public void SpawnEnemies() { 

        float ang = Random.value * 360;
        Vector3 center = transform.position;
        for (int i = 0; i < numObjects; i++)
        {

            Vector3 pos = RandomCircle(center, 8f, ang); //center, radius
            Vector3 Finalpos = RandomCircle(center, 35f, ang);
            Quaternion rot = Quaternion.FromToRotation(Vector3.forward, center - pos);
            var enemy = Instantiate(prefab, pos, rot) as GameObject;
            enemy.GetComponent<EnemyMovement1>().start = pos;
            enemy.GetComponent<EnemyMovement1>().end = Finalpos;
            enemy.GetComponent<EnemyMovement1>().index = i;
            ang = ang + 6; // increase angle a bit per loop
        }
    }

    Vector3 RandomCircle(Vector3 center, float radius, float ang)
    {
        
        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.y = center.y;  //+ radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        pos.z = center.z + radius * Mathf.Cos(ang * Mathf.Deg2Rad); 
        return pos;
    }
}

