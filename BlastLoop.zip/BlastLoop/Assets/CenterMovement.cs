﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CenterMovement : MonoBehaviour
{
    public GameObject centerTargetPoint;
    float rot = 0.0f; // current rotation
    public float EnemySpeed = 30f;

    float amplitudeX = 2.0f;
    float amplitudeY = 1.0f;
    float omegaX = 1.0f;
    float omegaY = 2.0f;
    float index;
    public bool sinwave = true;

  


    void Start()
    {

        rot = EnemySpeed * Time.deltaTime;
        centerTargetPoint = GameObject.Find("Center");
      

    }


    


    void Update()
    {

            transform.RotateAround(centerTargetPoint.transform.position, Vector3.up, rot);
        

        if(sinwave == true)
        {
            index += Time.deltaTime;
            float x = amplitudeX * Mathf.Cos(omegaX * index);
            float y = Mathf.Abs(amplitudeY * Mathf.Sin(omegaY * index));
            transform.localPosition = new Vector3(transform.localPosition.x, y, transform.localPosition.z);
        }

    }


    void OnTriggerEnter(Collider col)
    {
        //  Debug.Log("Colliding");
        //damage what you hit if player

        if (col.tag == "Player")
        {
            col.GetComponent<RotationControl>().health--;
            if (col.GetComponent<RotationControl>().health == 0)
            {
                Debug.Log("Game Over");
                Destroy(col.gameObject);
            }
            else
            {
                Debug.Log("Health = " + col.GetComponent<RotationControl>().health);
            }
            Destroy(gameObject);
        }

       
    }
}
