﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement1 : MonoBehaviour
{
    public GameObject centerTargetPoint;
    float rot = 0.0f; // current rotation
    public float EnemySpeed = 70f;
    public int enemyHealth;

    float amplitudeX = 10.0f;
    float amplitudeY = 5.0f;
    float omegaX = 0.5f;
    float omegaY = 1.0f;
    public float index;
    public bool sinwave = false;
    public bool swapRot;

    //lerp details
   public Vector3 start;
    public Vector3 end;


    public Renderer rend;
    public Material redMatRef;
    public Material oldMat;
    public Material damagedMat;
    public GameObject explodeParticle;
    


    void Start()
    {
        rend = GetComponent<Renderer>();
        rot = EnemySpeed * Time.deltaTime;
        centerTargetPoint = GameObject.Find("Center");
        StartCoroutine(Lerp());
        
    }


    IEnumerator Lerp()
    {
        float timeElapsed = 0;
        float lerpDuration = 1.2f;

        while (timeElapsed < lerpDuration)
        {
            transform.position = Vector3.Lerp(start, end, timeElapsed / lerpDuration);
            timeElapsed += Time.deltaTime;

            yield return null;
        }

        transform.position = end;
    }


    void Update()
    {
        if (swapRot == true)
        {
            transform.RotateAround(centerTargetPoint.transform.position, Vector3.up, -rot);
        }
        else
        {
            transform.RotateAround(centerTargetPoint.transform.position, Vector3.up, rot);
        }

        if(sinwave == true)
        {
            index += Time.deltaTime;
            float x = amplitudeX * Mathf.Cos(omegaX * index);
            float y = Mathf.Abs(amplitudeY * Mathf.Sin(omegaY * index));
            transform.localPosition = new Vector3(transform.localPosition.x, y, transform.localPosition.z);
        }

    }


    void OnTriggerEnter(Collider col)
    {
        //  Debug.Log("Colliding");
        //damage what you hit if player

        if (col.tag == "Player")
        {
           
            col.GetComponent<RotationControl>().SetHealth();
            if (col.GetComponent<RotationControl>().health == 0)
            {
                col.GetComponent<RotationControl>().GameOver();
                Debug.Log("Game Over");
                Instantiate(explodeParticle, col.transform.position, col.transform.rotation);
                Destroy(col.gameObject);
                
               
            }
            else
            {
                Debug.Log("Health = " + col.GetComponent<RotationControl>().health);
            }
            Destroy(gameObject);
        }

       
    }

    public void HealthRed()
    {
        StartCoroutine(Redder());
        //flash red for a sec
        
    }
    IEnumerator Redder()
    {
       
        rend.material = redMatRef;
        yield return new WaitForSeconds(0.2f);
        if (enemyHealth < 8)
        {
            rend.material = damagedMat;
        }
        else
        {
            rend.material = oldMat;
        }
        
        yield return 0;
    }
}
