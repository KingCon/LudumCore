﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CentralSpinner : MonoBehaviour
{

    public int numObjects = 10;
    public GameObject prefab;

    
    void Start()
    {
        float ang = Random.value * 360;
        Vector3 center = transform.position;
        for (int i = 0; i < numObjects; i++)
        {

            Vector3 pos = RandomCircle(center, 6f, ang); //center, radius
         
            Quaternion rot = Quaternion.FromToRotation(Vector3.forward, center - pos);
             Instantiate(prefab, pos, rot);
           
            ang = ang + 20; // increase angle a bit per loop
        }


        for (int i = 0; i < numObjects; i++)
        {

            Vector3 pos = RandomCircle2(center, 6f, ang); //center, radius

            Quaternion rot = Quaternion.FromToRotation(Vector3.forward, center - pos);
            Instantiate(prefab, pos, rot);

            ang = ang + 20; // increase angle a bit per loop
        }
        for (int i = 0; i < numObjects; i++)
        {

            Vector3 pos = RandomCircle3(center, 5f, ang); //center, radius

            Quaternion rot = Quaternion.FromToRotation(Vector3.forward, center - pos);
            Instantiate(prefab, pos, rot);

            ang = ang + 20; // increase angle a bit per loop
        }

    }

    Vector3 RandomCircle(Vector3 center, float radius, float ang)
    {
        
        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.y = center.y;// + radius * Mathf.Tan(ang * Mathf.Deg2Rad);
        pos.z = center.z + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        return pos;
    }

    Vector3 RandomCircle2(Vector3 center, float radius, float ang)
    {

        Vector3 pos;
        pos.x = center.x;// + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.y = center.y + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.z = center.z + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        return pos;
    }

    Vector3 RandomCircle3(Vector3 center, float radius, float ang)
    {

        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.y = center.y + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        pos.z = center.z;//+ radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        return pos;
    }

}

