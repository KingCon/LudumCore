﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletMovement : MonoBehaviour
{
    public GameObject centerTargetPoint;
    float rot = 0.0f; // current rotation
    public float BulletSpeed = 100f;
    public float TimeToLive = 1.2f;
    public bool currentDirection;
    public GameObject explodeParticle;


    void Start()
    {
        
        rot = BulletSpeed * Time.deltaTime;
        centerTargetPoint = GameObject.Find("Center");
        Destroy(gameObject, TimeToLive);
    }

    void Update()
    {
       

        if (currentDirection == true)
        {
            transform.RotateAround(centerTargetPoint.transform.position, Vector3.up, rot);
        }
        else
        {
            transform.RotateAround(centerTargetPoint.transform.position, Vector3.up, -rot);
        }
      

    }

    void OnTriggerEnter(Collider col)
    {
        //Debug.Log("Colliding");
        if(col.tag == "Enemy")
        {
            int enemyHealth = col.GetComponent<EnemyMovement1>().enemyHealth--;
            
            enemyHealth--;//lower enemy health before destroying enemy

            if(enemyHealth <= 0)
            {
                Instantiate(explodeParticle, col.transform.position,col.transform.rotation);
                Destroy(col.gameObject);
            }
            col.GetComponent<EnemyMovement1>().HealthRed();
        }
        Destroy(gameObject);
    }
}
