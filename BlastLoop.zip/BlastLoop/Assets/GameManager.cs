﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{

    public SpawnEnemyOut BasicSpawner;
    public SpawnEnemySplit SplitHeightSpawner;
    public AudioSource audioSource;
    int centerLayerindex = 0;

    public GameObject layer1;
    public GameObject layer2;
    public GameObject layer3;

    public GameObject particlePrefab;
    public GameObject gameWinCanvas;

    

    // Start is called before the first frame update
    void Start()
    {
        audioSource.Play();
        StartCoroutine(SpawnEnemies(4));
        
    }

   

    

  

IEnumerator SpawnEnemies(int number)
    { int i = 0;
       
        while (i < number)
        {
            BasicSpawner.SpawnEnemies();
            yield return new WaitForSeconds(5);
            SplitHeightSpawner.SpawnEnemies();
            i++;
            yield return 0;
        }
        Debug.Log("Round 1 completed");
    }

 
    
    // Update is called once per frame
    void Update()
    {
        //check if al enemies are dead
        var foundEnemyObjects = GameObject.FindGameObjectsWithTag("Enemy");
        if (foundEnemyObjects.Length == 0) {
          
            DestroyCenterlayer();
            
        };
    }
    void DestroyCenterlayer()
    {
        if (centerLayerindex == 0)
        {
            //destroy outer
            Instantiate(particlePrefab, layer3.transform);
            Destroy(layer1);
            centerLayerindex++;
            Debug.Log("Next Round Begin");
            StartCoroutine(SpawnEnemies(6));
        }
        else if (centerLayerindex == 1)
        {
            //inner 1
            Instantiate(particlePrefab, layer3.transform);
            Destroy(layer2);
            centerLayerindex++;
            Debug.Log("Next Round Begin");
            StartCoroutine(SpawnEnemies(12));
        }
        else
        {
            //inner 2
            Instantiate(particlePrefab, layer3.transform);
            Debug.Log("You Win");
            gameWinCanvas.SetActive(true);
            centerLayerindex = 0;
            Time.timeScale = 0;
        }
    }
}
