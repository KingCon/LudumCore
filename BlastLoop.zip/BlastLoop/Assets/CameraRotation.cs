﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraRotation : MonoBehaviour
{

    public GameObject centerTargetPoint;
    float rot = 0.0f; // current rotation
   
    Vector3 origin = Vector3.zero;
    public float speed = 100f;

    void Start()
    {
   
    }

    void Update()
    {
        
            rot = -Input.GetAxis("Horizontal") * speed * Time.deltaTime;
                   // Spin the object around the target at 20 degrees/second.
            transform.RotateAround(centerTargetPoint.transform.position, Vector3.up, rot);
    
        //transform.position = origin + Quaternion.Euler(rot, Vector3.up) * new Vector3(0f, 0f, distance);
    }





}
