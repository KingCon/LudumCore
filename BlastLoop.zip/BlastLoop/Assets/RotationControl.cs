﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RotationControl : MonoBehaviour
{
    public int health = 5;
    public int stamina;
    public int maxstamina;

    public GameObject centerTargetPoint;
    float rot = 0.0f; // current rotation
    float vert = 0.0f;
    Vector3 origin = Vector3.zero;
    public float speed = 100f;
    public bool setDirection;
    public GameObject Projectile;    // this is a reference to your projectile prefab
    public Transform SpawnTransform;
    public GameManager gameManagerRef;

    public GameObject healthBarRef;
    public GameObject staminaBarRef;
    public GameObject gameOverCanvas;


    void Start()
    {

        // rot = transform.eulerAngles.y;
        healthBarRef.GetComponent<Slider>().maxValue = health;
        healthBarRef.GetComponent<Slider>().value = health;
        staminaBarRef.GetComponent<Slider>().maxValue = stamina;
        staminaBarRef.GetComponent<Slider>().value = stamina;

    }


    public void SetHealth()
    {
        health--;
      
        healthBarRef.GetComponent<Slider>().value = health;

    }
    public void SetStamina()
    {
        staminaBarRef.GetComponent<Slider>().value = stamina;
    }

    public void GameOver()
    {
        gameOverCanvas.SetActive(true);
        Time.timeScale = 0;
    }

    void Update()
    {
        if(Input.GetAxis("Horizontal") > 0)
        {
            setDirection = false;
            //transform.rotation = Quaternion.Euler(transform.rotation.x, 180, transform.rotation.z);
            transform.localScale = new Vector3(1, 1, 1);
        }
        if(Input.GetAxis("Horizontal")< 0)
        {
            setDirection = true;
            transform.localScale = new Vector3(-1,1,-1);
        }
            rot = -Input.GetAxis("Horizontal") * speed * Time.deltaTime;
                   // Spin the object around the target at 20 degrees/second.
            transform.RotateAround(centerTargetPoint.transform.position, Vector3.up, rot);

        vert = Input.GetAxis("Vertical") * (speed * 0.07f);
            transform.Translate(Vector3.up * vert * Time.deltaTime);
        //transform.position = origin + Quaternion.Euler(rot, Vector3.up) * new Vector3(0f, 0f, distance);

        if (Input.GetAxis("Fire1") !=0)
        {
            if(setDirection == false && stamina !=0) // set bullet diretion
            {
                var bullet = Instantiate(Projectile, SpawnTransform.position, SpawnTransform.rotation) as GameObject;
                bullet.GetComponent<BulletMovement>().currentDirection = false;
                stamina--;
                SetStamina();
            }
            else if (setDirection == true && stamina != 0)
            {
                var bullet = Instantiate(Projectile, SpawnTransform.position, SpawnTransform.rotation) as GameObject;
                bullet.GetComponent<BulletMovement>().currentDirection = true;
                stamina--;
                SetStamina();
            }
           
                
        }
        if(Input.GetAxis("Fire1") == 0 && stamina != maxstamina)
        {
            stamina++;
            SetStamina();
        }

    }





}
