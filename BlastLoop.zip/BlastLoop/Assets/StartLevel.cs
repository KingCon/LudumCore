﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartLevel : MonoBehaviour
{

    public string nextScene;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void NextLevel()
    {
        Debug.Log("Starting level");
        SceneManager.LoadScene(nextScene);
    }


    public void ReloadLevel()
    {
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
        Time.timeScale = 1;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
